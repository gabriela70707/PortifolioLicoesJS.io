// Funções : Bloco de código que pode ser reutilizado 
// Normalmente contem a resolução ou parte dela para solucionar um problema
// A palavra reservada para a função no JS é "function"
//Normalmete por boa pratica as funções ficam no topo da pagina
//function o nome do que eu quero fazer a passagem de paramentros e {} para o bloco de codigo


function saudar(){  
    alert("Parabéns vocês voltaram a vida normal")
}

function soma(a = 0 , b = 0){ //Colocar um valor default ajuda a evitar erros caso usuario nao preencha todos os parametros
    return a + b
}

function converterMaiuscula(texto){
    return texto.toUpperCase() //pega o texto que ira receber como parametro e retorna ele em maiusculo
}


//Arrow function é a nova estrutura de funções para resoluções mais simplorias. Ele é declarado como uma constante, fazendo a tratativa como uma variavel
//a Ideia é que seja  sempre a execução de uum código especifico


//contante /  nome da variavel/ parametros / o quero que seja feito
const dividir = (valor1, valor2) => valor1/valor2



//CHAMADA DA ARROW FUNCTION
alert(`Essa é uma execução de Arrow Function ${dividir(10,5)}`)

//CHAMADAS DAS FUNÇÕES
saudar();




a = Number(prompt("Informe o valor de A: "))
b = Number(prompt("Informe o valor de B: "))


resultado = soma(a, b); //variavel que esta recebendo o retorno da função soma
document.write(resultado)

texto = prompt("Informe seu texto: ")
convertido = converterMaiuscula(texto)
document.write(convertido)





//Performe de codigo : importante estudar