// variaveis: espaço em memoria para guardae valores
//variaveis: let, const, var e array
//let: tudo que varia, valores flexíveis para armazenar 1 dado
//const: que nao varia, valores fixos
//var: primeira forma de declarar uma variavel em sistemas legados.
//array: é uma variavel que armazena varios valores de um conjunto. Esse conjunto recebe um indice começando em 0

//array é determinado usando os colchetes []
let numero = [5,10,20,7,70,1,2]

let nomes = ['Gabs', 'Joyce', 'Ariane', 'Nico', 'Ge', 'Joao']


//exibição dos indices de um array
// for (let indice in numeros){ 
//     alert (indice)
// }



// for (let valor of nomes){
//     alert(valor)
// }

//percorrer o Array com forEach
numero.forEach(function (valor){
    document.write(`${valor} <br>`)
})


//inserindo no final do array com o push
//já devo colocar o valor que quero no final da fila
numero.push(70)
document.write(`${numero}<p>`)


//inserindo no inicio do Array com unshift
numero.unshift(0)
document.write(`${numero} <br>`)


//Excluindo o ultimo elemento com o pop
numero.pop()
document.write(`${numero} <p>`)



//excluindo o primiero elemento da lista
numero.shift()
document.write(`${numero} <p>`)


//funções callback: são funções que criam novos arrays como resposta de uma tentativa de manipulação do array original, não editando o original
//seria como se fosse uma versaõ de um array porem seguindo as condições impostas

//map - pega o array original e cria outro como resposta



let numerosQuadrados = numero.map(n => n**2)
document.write(`Numeros da lista elevados ao quadrado: <p>`)
document.write(`${numerosQuadrados} <p>`)


let nomeGrandes = nomes.map(nome => nome.toUpperCase())
document.write(`${nomeGrandes} <p>`)


//filter - ele gera um outro array de retorno com os valores que satisfazem uma condição
let numerosPares = numeros.filter(function(numero){
    return numero % 2 == 0 
})


//find: ele percorre um array original e assim que acha um valor que atenda a condição ele para de percorrer e retorna esse valor encontrado
let primeiroPar = numero.find(function(numero){
    numero % 2 == 0
})
document.write(`O primeiro numero par é: ${primeiroPar}`)


//spread
//como eu junto dois arrays 
let livrosP = ['ler um café e tomar uma poesia', 'para você que teve um dia ruim', 'extraordinário']
let livrosC = ['Diario de um banana', 'it a coisa', 'harry potter']

catalogo = [...livrosP, ...livrosC]
document.write(catalogo)